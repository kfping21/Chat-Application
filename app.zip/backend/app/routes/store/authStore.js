const { query, queryOne } = require("./commonStore");

async function createUser({ username, password, displayName }) {
  const existing = await getUserByUsername(username);
  if (existing) return null;
  const result = await query("INSERT INTO users (anonymous_name, avatar_color) VALUES (?, ?)", [username, password]);
  return {
    id: Number(result.insertId),
    username,
    password,
    displayName: displayName || username,
    createdAt: new Date().toISOString()
  };
}

async function getUserByUsername(username) {
  const user = await queryOne(
    "SELECT id, anonymous_name, avatar_color, joined_at FROM users WHERE anonymous_name = ? LIMIT 1",
    [username]
  );
  if (!user) return null;
  return {
    id: Number(user.id),
    username: user.anonymous_name,
    password: user.avatar_color,
    displayName: user.anonymous_name,
    createdAt: user.joined_at
  };
}

async function createSession(userId) {
  const token = `tk_${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
  await query(
    `INSERT INTO notifications (user_id, type, ref_id, payload, is_read, created_at)
     VALUES (?, 'auth_session', ?, JSON_OBJECT('token', ?), 0, CURRENT_TIMESTAMP)`,
    [userId, userId, token]
  );
  return token;
}

async function getSession(token) {
  const row = await queryOne(
    `SELECT user_id, created_at
     FROM notifications
     WHERE type = 'auth_session'
       AND is_read = 0
       AND JSON_UNQUOTE(JSON_EXTRACT(payload, '$.token')) = ?
     ORDER BY id DESC
     LIMIT 1`,
    [token]
  );
  if (!row) return null;
  return { userId: Number(row.user_id), createdAt: row.created_at };
}

async function deleteSession(token) {
  await query(
    `UPDATE notifications
     SET is_read = 1
     WHERE type = 'auth_session'
       AND is_read = 0
       AND JSON_UNQUOTE(JSON_EXTRACT(payload, '$.token')) = ?`,
    [token]
  );
}

module.exports = {
  createUser,
  getUserByUsername,
  createSession,
  getSession,
  deleteSession
};
